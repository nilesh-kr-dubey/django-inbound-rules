from django.apps import AppConfig


class DjangoInboundConfig(AppConfig):
    name = 'django_inbound'
